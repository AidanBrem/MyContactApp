//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;
import java.lang.Math;

public class Prime
{
	private int number;

	public Prime()
	{


	}

	public Prime(int num)
	{


	}

	public void setPrime(int num)
	{


	}

	public boolean isPrime()
	{







		return true;
	}

	public String toString()
	{
		String output="";







		return output;
	}
}